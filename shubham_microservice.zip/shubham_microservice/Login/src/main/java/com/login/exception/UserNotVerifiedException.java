package com.login.exception;

public class UserNotVerifiedException extends Exception {

	public UserNotVerifiedException(String errorMsg) {
		super(errorMsg);
	}
}
