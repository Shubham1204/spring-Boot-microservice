package com.login.exception;

public class InvalidParametersException extends Exception {

	public InvalidParametersException(String errorMsg) {
		super(errorMsg);
	}
}
