package com.login.exception;

public class RoleNotFoundException extends Exception {

	public RoleNotFoundException(String errorMsg) {
		super(errorMsg);
	}
}
