package com.login.exception;

public class UnableToAddException extends Exception {

	public UnableToAddException(String errorMsg) {
		super(errorMsg);
	}
}
