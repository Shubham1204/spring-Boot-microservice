package com.login.exception;

public class UserRoleNotMappedException extends Exception {

	public UserRoleNotMappedException(String errorMsg) {
		super(errorMsg);
	}
}
