package com.login.exception;

public class RightNotFoundException extends Exception {

	public RightNotFoundException(String errorMsg) {
		super(errorMsg);
	}
}
