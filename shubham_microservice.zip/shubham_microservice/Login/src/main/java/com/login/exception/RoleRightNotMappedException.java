package com.login.exception;

public class RoleRightNotMappedException extends Exception {

	public RoleRightNotMappedException(String errorMsg) {
		super(errorMsg);
	}
}
