package com.login.exception;

public class RightExistsException extends Exception {

	public RightExistsException(String errorMsg) {
		super(errorMsg);
	}
}
