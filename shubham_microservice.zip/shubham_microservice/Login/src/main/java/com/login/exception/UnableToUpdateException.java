package com.login.exception;

public class UnableToUpdateException extends Exception {

	public UnableToUpdateException(String errorMsg) {
		super(errorMsg);
	}
}
