package com.login.exception;

public class InvalidOtpException extends Exception {

	public InvalidOtpException(String errorMsg) {
		super(errorMsg);
	}
}
