package com.login.exception;

public class RoleNotSavedException extends Exception {

	public RoleNotSavedException(String errorMsg) {
		super(errorMsg);
	}
}
